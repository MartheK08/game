# BREAKOUT GAME 
# Door Ahmed en Marthe

import pygame, time

# Constanten bepalen 
FPS = 30 # Frames Per Second
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
BALL_WIDTH = 16
BALL_HEIGHT = 16
PADDLE_WIDTH = 144
PADDLE_HEIGHT = 32
BRICK_WIDTH = 96
BRICK_HEIGHT = 32

# Variabelen 
game_status = 'keuze'
reset = False
running = True
pauze = False
score = 0

ball_x = 0
ball_speed_x = 6
ball_y = 0
ball_speed_y = 9

paddle_x = SCREEN_WIDTH / 2 - 72
paddle_y = SCREEN_HEIGHT - 57
welke_paddle = 1
paddle_speed = 15

vallende_blokken_x = []
vallende_blokken_y = []

bricks_x = [376, 472, 568, 664, 760, 856,
            328, 424, 520, 616, 712, 808,
            376, 472, 568, 664, 760, 856,
            328, 424, 520, 616, 712, 808]
bricks_y = [196, 196, 196, 196, 196, 196,
            228, 228, 228, 228, 228, 228,
            260, 260, 260, 260, 260, 260,
            292, 292, 292, 292, 292, 292]

welk_blok = '1'
kleur_blok = '-'

levens = 3

# Het opstarten van de game 
pygame.init()
font = pygame.font.SysFont('default', 64)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
fps_clock = pygame.time.Clock()


# Om afbeeldingen te kunnen 'lezen'
spritesheet = pygame.image.load('Breakout_Tile_Free.png').convert_alpha() # convert_alpha increases speed of blit and keeps transparancy of .png

# De afbeelding van de bal
ball_img = pygame.Surface((64, 64)) # create new image
ball_img.blit(spritesheet, (0, 0), (1403, 652, 64, 64))  # copy part of sheet to image
ball_img = pygame.transform.scale(ball_img, (BALL_WIDTH, BALL_HEIGHT)) # resize

# De afbeelding van de plank
paddle1_img = pygame.Surface((243, 64)) # create new image
paddle1_img.blit(spritesheet, (0, 0), (1158, 462, 243, 64))  # copy part of sheet to image
paddle1_img = pygame.transform.scale(paddle1_img, (PADDLE_WIDTH, PADDLE_HEIGHT))
paddle2_img = pygame.Surface((243, 64)) # create new image
paddle2_img.blit(spritesheet, (0, 0), (1158, 528, 243, 64))  # copy part of sheet to image
paddle2_img = pygame.transform.scale(paddle2_img, (PADDLE_WIDTH, PADDLE_HEIGHT))
paddle3_img = pygame.Surface((243, 64)) # create new image
paddle3_img.blit(spritesheet, (0, 0), (1158, 594, 243, 64))  # copy part of sheet to image
paddle3_img = pygame.transform.scale(paddle3_img, (PADDLE_WIDTH, PADDLE_HEIGHT))

# De afbeelding van het blok in 8 verschillende kleuren
brick1_img = pygame.Surface((384, 128)) # rood
brick1_img.blit(spritesheet, (0, 0), (772, 260, 384, 128))
brick1_img = pygame.transform.scale(brick1_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick2_img = pygame.Surface((384, 128)) # oranje
brick2_img.blit(spritesheet, (0, 0), (772, 0, 384, 128))
brick2_img = pygame.transform.scale(brick2_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick3_img = pygame.Surface((384, 128)) # geel
brick3_img.blit(spritesheet, (0, 0), (386, 390, 384, 128))
brick3_img = pygame.transform.scale(brick3_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick4_img = pygame.Surface((384, 128)) # lichtgroen
brick4_img.blit(spritesheet, (0, 0), (0, 130, 384, 128))
brick4_img = pygame.transform.scale(brick4_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick5_img = pygame.Surface((384, 128)) # donkergroen
brick5_img.blit(spritesheet, (0, 0), (386, 130, 384, 128))
brick5_img = pygame.transform.scale(brick5_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick6_img = pygame.Surface((384, 128)) # donkerblauw
brick6_img.blit(spritesheet, (0, 0), (772, 390, 384, 128))
brick6_img = pygame.transform.scale(brick6_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick7_img = pygame.Surface((384, 128)) # lichtblauw
brick7_img.blit(spritesheet, (0, 0), (386, 650, 384, 128))
brick7_img = pygame.transform.scale(brick7_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick8_img = pygame.Surface((384, 128)) # paars
brick8_img.blit(spritesheet, (0, 0), (0, 390, 384, 128))
brick8_img = pygame.transform.scale(brick8_img, (BRICK_WIDTH, BRICK_HEIGHT))
brick9_img = pygame.Surface((384, 128)) # grijs
brick9_img.blit(spritesheet, (0, 0), (772, 520, 384, 128))
brick9_img = pygame.transform.scale(brick9_img, (BRICK_WIDTH, BRICK_HEIGHT))

# de afbeelding van het levens-hartje
hartje_img = pygame.Surface((64, 64))
hartje_img.blit(spritesheet, (0, 0), (1637, 652, 64, 58))
hartje_img = pygame.transform.scale(hartje_img, (64, 58))

# alle berichten
# Het score bericht staat onder running
kleur_kiezen_bericht = "Kies je kleur blok:"
kleur_kiezen_img = font.render(kleur_kiezen_bericht, True, 'white')
kleur_kiezen_width = kleur_kiezen_img.get_width()
kleur_kiezen2_bericht = "1: rood, 2: oranje, 3: geel, 4: lichtgroen, 5: donkergroen,"
kleur_kiezen2_img = font.render(kleur_kiezen2_bericht, True, 'white')
kleur_kiezen2_width = kleur_kiezen2_img.get_width()
kleur_kiezen3_bericht = "6: donkerblauw, 7: lichtblauw, 8: paars, 9: regenboog"
kleur_kiezen3_img = font.render(kleur_kiezen3_bericht, True, 'white')
kleur_kiezen3_width = kleur_kiezen3_img.get_width()
start_bericht = "Klik op [i] voor meer info"
start_img = font.render(start_bericht, True, 'white')
start_width = start_img.get_width()
info1_bericht = "Klik op [enter] om te beginnen"
info1_img = font.render(info1_bericht, True, 'white')
info1_width = info1_img.get_width()
info2_bericht = "Speel met [<-] en [->]"
info2_img = font.render(info2_bericht, True, 'white')
info2_width = info2_img.get_width()
info3_bericht = "Klik op [spatie] voor pauze"
info3_img = font.render(info3_bericht, True, 'white')
info3_width = info3_img.get_width()
info4_bericht = "Om te resetten en opnieuw te beginnen, klik [r]"
info4_img = font.render(info4_bericht, True, 'white')
info4_width = info4_img.get_width()
info5_bericht = "[s] is om terug te gaan naar het startscherm"
info5_img = font.render(info5_bericht, True, 'white')
info5_width = info5_img.get_width()
game_over_bericht = "GAME OVER!"
game_over_img = font.render(game_over_bericht, True, 'black')
game_over_width = game_over_img.get_width()
gewonnen_bericht = "YOU WON!"
gewonnen_img = font.render(gewonnen_bericht, True, 'black')
gewonnen_width = gewonnen_img.get_width()
opnieuw_spelen_bericht = "Druk op [enter] om opnieuw te spelen"
opnieuw_spelen_img = font.render(opnieuw_spelen_bericht, True, 'white')
opnieuw_spelen_width = opnieuw_spelen_img.get_width()
pauze1_bericht = "Druk op [escape] om verder te gaan"
pauze1_img = font.render(pauze1_bericht, True, 'white')
pauze1_width = pauze1_img.get_width()
pauze2_bericht = "Of druk op [r] om opnieuw te beginnen"
pauze2_img = font.render(pauze2_bericht, True, 'white')
pauze2_width = pauze2_img.get_width()






# hier start het spel (als running is True)
print('mygame is running')
while running:
    # het stoppen van het spel
    for event in pygame.event.get():
       if event.type == pygame.QUIT:
          running = False
    keys = pygame.key.get_pressed()

    # Het score bericht (dat steeds moet worden bijgewerkt en daarom hier staat)
    score_bericht = "Score: " + str(score)
    score_img = font.render(score_bericht, True, 'white')
    score_width = score_img.get_width()

    # Het keuze menu
    if game_status == 'keuze':
       screen.fill('black')
       screen.blit(kleur_kiezen_img, ((SCREEN_WIDTH - kleur_kiezen_width) // 2, SCREEN_HEIGHT // 2 - 100))
       screen.blit(kleur_kiezen2_img, ((SCREEN_WIDTH - kleur_kiezen2_width) // 2, SCREEN_HEIGHT // 2))
       screen.blit(kleur_kiezen3_img, ((SCREEN_WIDTH - kleur_kiezen3_width) // 2, SCREEN_HEIGHT // 2 + 100))
       pygame.display.flip()
       kleur_blok = '-'
       if keys[pygame.K_1]:
          brick_img = brick1_img
          game_status = 'intro'
       elif keys[pygame.K_2]:
          brick_img = brick2_img
          game_status = 'intro'
       elif keys[pygame.K_3]:
          brick_img = brick3_img
          game_status = 'intro'
       elif keys[pygame.K_4]:
          brick_img = brick4_img
          game_status = 'intro'
       elif keys[pygame.K_5]:
          brick_img = brick5_img
          game_status = 'intro'
       elif keys[pygame.K_6]:
          brick_img = brick6_img
          game_status = 'intro'
       elif keys[pygame.K_7]:
          brick_img = brick7_img
          game_status = 'intro'
       elif keys[pygame.K_8]:
          brick_img = brick8_img
          game_status = 'intro'
       elif keys[pygame.K_9]:
          kleur_blok = 'regenboog'
          game_status = 'intro'
          

    # Het introductie scherm
    elif game_status == 'intro':
       reset = True
       screen.fill('black')
       screen.blit(info1_img, ((SCREEN_WIDTH - info1_width) // 2, SCREEN_HEIGHT // 2 - 100))
       screen.blit(start_img, ((SCREEN_WIDTH - start_width) // 2, SCREEN_HEIGHT // 2))
       pygame.display.flip()
       if keys[pygame.K_RETURN]:
          game_status = 'spelen'
       if keys[pygame.K_i]:
          game_status = 'info'
       elif keys[pygame.K_s]:
          game_status = 'keuze'
    
    elif game_status == 'info':
       screen.fill('black')
       screen.blit(info1_img, ((SCREEN_WIDTH - info1_width) // 2, SCREEN_HEIGHT // 2 - 150))
       screen.blit(info2_img, ((SCREEN_WIDTH - info2_width) // 2, SCREEN_HEIGHT // 2 - 75))
       screen.blit(info3_img, ((SCREEN_WIDTH - info3_width) // 2, SCREEN_HEIGHT // 2))
       screen.blit(info4_img, ((SCREEN_WIDTH - info4_width) // 2, SCREEN_HEIGHT // 2 + 75))
       screen.blit(info5_img, ((SCREEN_WIDTH - info5_width) // 2, SCREEN_HEIGHT // 2 + 150))
       pygame.display.flip()
       if keys[pygame.K_RETURN]:
          game_status = 'spelen'
       elif keys[pygame.K_s]:
          game_status = 'keuze'

    elif game_status == 'spelen':
    
      # Bewegen van de plank
       if keys[pygame.K_RIGHT] : 
          paddle_x += paddle_speed
       elif keys[pygame.K_LEFT] :
          paddle_x -= paddle_speed
   
       # Paddle binnen het scherm houden
       if paddle_x + PADDLE_WIDTH > SCREEN_WIDTH:
          paddle_x = SCREEN_WIDTH - PADDLE_WIDTH
       elif paddle_x < 0 : 
          paddle_x = 0
    
       # bal bewegen
       ball_x = ball_x + ball_speed_x
       ball_y = ball_y + ball_speed_y
    
       # bal stuiteren tegen de randen van het scherm
       if ball_x < 0:
         ball_x = 0
         ball_speed_x = ball_speed_x * -1
       elif ball_x + BALL_WIDTH > SCREEN_WIDTH:
         ball_x = SCREEN_WIDTH - BALL_WIDTH
         ball_speed_x = ball_speed_x * -1
       elif ball_y < 0 :
         ball_speed_y = ball_speed_y * -1
         ball_y = 0
      
       # Stuiteren van de bal op de plank
       if (ball_x + BALL_WIDTH > paddle_x and 
           ball_x < paddle_x + PADDLE_WIDTH and 
           ball_y + BALL_HEIGHT > paddle_y and 
           ball_y < paddle_y + PADDLE_HEIGHT) :
           ball_speed_y *= -1
           ball_y = paddle_y - BALL_HEIGHT + 1
           # Als de bal vanaf de linkerkant op de linkerkant van de paddle stuitert
           # of vanaf de rechterkant op de rechterkant op de paddle
           # of als de bal vanaf de linkerkant komt, terwijl de paddle naar rechts beweegt
           # of als de bal vanaf de rechterkant komt, terwijl de paddle naar links beweegt
           if (ball_x + BALL_WIDTH < paddle_x + PADDLE_WIDTH / 5 and ball_speed_x > 0 or
              ball_x > paddle_x + PADDLE_WIDTH - PADDLE_WIDTH / 5 and ball_speed_x < 0 or
              keys[pygame.K_LEFT] and ball_speed_x > 0 or
              keys[pygame.K_RIGHT] and ball_speed_x < 0):
             ball_speed_x *= -1
           else:
              ball_speed_x *= 1
           

       # Stuiteren van de bal op het blok 
       # ook verkleuring blok, blok weg en verandering snelheid bal en paddle
       for i in range(len(bricks_x) -1, -1, -1):
          if (ball_x + BALL_WIDTH > bricks_x[i] and 
              ball_x < bricks_x[i] + BRICK_WIDTH and 
              ball_y + BALL_HEIGHT > bricks_y[i] and 
              ball_y < bricks_y[i] + BRICK_HEIGHT) :
             # Als de bal van boven of onder komt
             if ((ball_speed_y > 0 and
                  ball_y + BALL_HEIGHT > bricks_y[i]) or 
                  (ball_speed_y < 0 and 
                   ball_y < bricks_y[i] + BRICK_HEIGHT)):
                if ball_speed_y <= 14:
                   ball_speed_y *= -1.05
                   ball_speed_x *= 1.05
                   paddle_speed *= 1.1
                else:
                   ball_speed_y *= -1
             # Als de bal van links of rechts komt
             elif ((ball_speed_x > 0 and
                  ball_x < bricks_x[i]) or 
                  (ball_speed_x < 0 and 
                   ball_x + BALL_WIDTH > bricks_x[i] + BRICK_WIDTH)):
                if ball_speed_y <= 14:
                   ball_speed_x *= -1.05
                   ball_speed_y *= 1.05
                   paddle_speed *= 1.1
                else:
                   ball_speed_x *= -1
             vallende_blokken_x.append(bricks_x[i])
             vallende_blokken_y.append(bricks_y[i])
             bricks_x.pop(i)
             bricks_y.pop(i)
             welk_blok += 1
             score += 10

       # detectie van aanraking vallend blok en plank
       for i in range(len(vallende_blokken_x) -1, -1, -1):
          if (paddle_x + PADDLE_WIDTH > vallende_blokken_x[i] and 
              paddle_x < vallende_blokken_x[i] + BRICK_WIDTH and 
              paddle_y + PADDLE_HEIGHT > vallende_blokken_y[i] and 
              paddle_y < vallende_blokken_y[i] + BRICK_HEIGHT) :
             score += 25
             vallende_blokken_x.pop(i)
             vallende_blokken_y.pop(i)

       # scherm 'wissen'
       screen.fill('black')

       # projectie van de levenshartjes
       for i in range(1, levens + 1):
             hartje_x = 1280 - (74*int(i))
             screen.blit(hartje_img, (hartje_x, 10))
      
       # projectie van de score
       
       screen.blit(score_img, (10, 10))

       # projectie van de plank
       if welke_paddle == 1 or welke_paddle == 2:
          screen.blit(paddle1_img, (paddle_x, paddle_y))
          welke_paddle += 1
       elif welke_paddle == 3 or welke_paddle == 4:
          screen.blit(paddle2_img, (paddle_x, paddle_y))
          welke_paddle += 1
       elif welke_paddle == 5:
          screen.blit(paddle3_img, (paddle_x, paddle_y))
          welke_paddle += 1
       else:
          screen.blit(paddle3_img, (paddle_x, paddle_y))
          welke_paddle = 1

       # projectie van het blok (in acht verschillende kleuren)
       if kleur_blok == 'regenboog':
          if welk_blok == 1:
             for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick1_img, (bricks_x[i], bricks_y[i]))
          elif welk_blok == 2:
              for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick2_img, (bricks_x[i], bricks_y[i]))
          elif welk_blok == 3:
              for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick3_img, (bricks_x[i], bricks_y[i]))
          elif welk_blok == 4:
              for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick4_img, (bricks_x[i], bricks_y[i]))
          elif welk_blok == 5:
              for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick5_img, (bricks_x[i], bricks_y[i]))
          elif welk_blok == 6:
              for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick6_img, (bricks_x[i], bricks_y[i]))
          elif welk_blok == 7:
              for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick7_img, (bricks_x[i], bricks_y[i]))     
          else:
             welk_blok = 0
             for i in range(len(bricks_x) -1, -1, -1):
                screen.blit(brick8_img, (bricks_x[i], bricks_y[i]))
       else:
          for i in range(len(bricks_x) -1, -1, -1):
             screen.blit(brick_img, (bricks_x[i], bricks_y[i]))

      # projectie van de vallende blokken
       for i in range(len(vallende_blokken_x) -1, -1, -1):
          screen.blit(brick9_img, (vallende_blokken_x[i], vallende_blokken_y[i]))
          vallende_blokken_y[i] += 10
          if vallende_blokken_y[i] > 720:
             vallende_blokken_x.pop(i)
             vallende_blokken_y.pop(i)

      # projectie van de bal
       screen.blit(ball_img, (ball_x, ball_y))

      # Check of de bal uit het veld is gegaan
       if ball_y + BALL_HEIGHT > SCREEN_HEIGHT and levens != 0:
          levens -= 1
          ball_x = 0
          ball_y = 0
          paddle_speed = 10
          ball_speed_x = 6
          ball_speed_y = 9
          paddle_x = SCREEN_WIDTH / 2 - 72
          paddle_y = SCREEN_HEIGHT - 57
          vallende_blokken_x.clear()
          vallende_blokken_y.clear()
   
      # Check of je hebt verloren
       if levens == 0:
          game_status = 'verloren'
      # Check of je hebt gewonnen
       if len(bricks_x) == 0:
          game_status = 'gewonnen'     
      # Check voor pauze
       if keys[pygame.K_SPACE]:
          game_status = 'pauze' 
      # Check voor reset
       if keys[pygame.K_r]:
          reset = True     
      # Check voor terug naar intro
       if keys[pygame.K_s]:
          game_status = 'keuze'
      
      # Het scherm tonen
       pygame.display.flip()

    elif game_status == 'pauze':
       screen.blit(pauze1_img, ((SCREEN_WIDTH - pauze1_width) // 2, SCREEN_HEIGHT // 2))
       screen.blit(pauze2_img, ((SCREEN_WIDTH - pauze2_width) // 2, SCREEN_HEIGHT // 2 + 100))
       pygame.display.flip()
       if keys[pygame.K_ESCAPE]:
          game_status = 'spelen'
       elif keys[pygame.K_r]:
          reset = True
          game_status = 'spelen'
       elif keys[pygame.K_s]:
          game_status = 'keuze'

    elif game_status == 'verloren':
       screen.fill('darkred')
       screen.blit(game_over_img, ((SCREEN_WIDTH - game_over_width) // 2, SCREEN_HEIGHT // 2 - 110))
       screen.blit(score_img, ((SCREEN_WIDTH - score_width) // 2, SCREEN_HEIGHT // 2 - 10))
       screen.blit(opnieuw_spelen_img, ((SCREEN_WIDTH - opnieuw_spelen_width) // 2, SCREEN_HEIGHT // 2 + 90))
       pygame.display.flip()
       if keys[pygame.K_RETURN] or keys[pygame.K_s]:
          reset = True
          game_status = 'keuze'
       elif keys[pygame.K_r]:
          game_status = 'spelen'

    elif game_status == 'gewonnen':
       screen.fill('darkgreen')
       score += levens * 100
       levens = 0
       screen.blit(gewonnen_img, ((SCREEN_WIDTH - gewonnen_width) // 2, SCREEN_HEIGHT // 2 - 110))
       screen.blit(score_img, ((SCREEN_WIDTH - score_width) // 2, SCREEN_HEIGHT // 2 - 10))
       screen.blit(opnieuw_spelen_img, ((SCREEN_WIDTH - opnieuw_spelen_width) // 2, SCREEN_HEIGHT // 2 + 90))
       pygame.display.flip()
       if keys[pygame.K_RETURN] or keys[pygame.K_s]:
          reset = True
          game_status = 'keuze'
       elif keys[pygame.K_r]:
          game_status = 'spelen'
    
    if reset == True:
       score = 0
       levens = 3
       welk_blok = 1
       ball_speed_x = 6
       ball_speed_y = 9
       ball_x = 0
       ball_y = 0
       paddle_speed = 10
       paddle_x = SCREEN_WIDTH / 2 - 72
       bricks_x = [376, 472, 568, 664, 760, 856,
                   328, 424, 520, 616, 712, 808,
                   376, 472, 568, 664, 760, 856,
                   328, 424, 520, 616, 712, 808]
       bricks_y = [196, 196, 196, 196, 196, 196,
                   228, 228, 228, 228, 228, 228,
                   260, 260, 260, 260, 260, 260,
                   292, 292, 292, 292, 292, 292] 
       vallende_blokken_x.clear()
       vallende_blokken_y.clear()
       reset = False

    # Het scherm de rest van dit frame bevriezen/slapen
    fps_clock.tick(FPS) 

print('mygame stopt running')